new Vue({
    el:"#app",
    data:{
      sports: {
        1: {
          sport:"BasketBall",
        },
        2: {
          sport:"Cricket"
        },
      },
      selectedSport: null
    },
    computed:{
      options(){
        return Object.keys(this.sports).map(k => {
          let o = this.sports[k]
          return `${o.sport}`
        })
      }
    }
  })