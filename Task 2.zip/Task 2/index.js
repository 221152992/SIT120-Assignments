const vueComponent = new Vue({
    el: "#checkboxes",
    data: {
        checkedboxes: []
    },
    methods: {
        
    }
})