var app = new Vue({
    el: '#app',
    data: {
        message: 'Prac 5 Task 2'
    }
});