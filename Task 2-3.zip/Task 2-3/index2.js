var app = new Vue({
    el: '#app2',
    data: {
        hide: true
    }
});